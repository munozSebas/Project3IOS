
import UIKit

import Nuke
class TrackCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var imageLabel: UIImageView!
    @IBOutlet weak var movieTitleLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    
    
    
    func configure(with movie: Movie) {
        movieTitleLabel.text = movie.movieTitle
        descLabel.text = movie.description
        
        Nuke.loadImage(with: movie.moviePoster, into: imageLabel)

    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
