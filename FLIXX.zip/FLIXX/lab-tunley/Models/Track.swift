import Foundation

// TODO: Pt 1 - Create a Track model struct
    
    struct Movie: Decodable {
        var movieTitle: String
        var description: String
        
        var moviePoster: URL
        static var posterBaseURLString: String = "https://image.tmdb.org/t/p/w185"

        var voteAverage: Double
        var voteCount: Int
        var popularity: Double
        
    }

extension Movie {

    /// An array of mock tracks
    static var mockMovies: [Movie]  = [
        Movie(movieTitle: "Avatar Way of the water",
              description: "Set more than a decade after the events of the first film, learn the story of the Sully family (Jake, Neytiri, and their kids), the trouble that follows them, the lengths they go to keep each other safe, the battles they fight to stay alive, and the tragedies they endure.",
              moviePoster: URL(string: "https://image.tmdb.org/t/p/w185/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg")!,
              voteAverage:7.7,
        voteCount:5181,
              popularity: 1666.27),
        
        Movie(movieTitle: "The Whale",
              description: "A reclusive English teacher suffering from severe obesity attempts to reconnect with his estranged teenage daughter for one last chance at redemption.",
              moviePoster: URL(string: "https://image.tmdb.org/t/p/w185/k2ez0xoCc2uDkRPqktGhW1qZzuP.jpg")!,
              voteAverage:7.4,
        voteCount:101,
              popularity: 624.61),
        
        Movie(movieTitle: "Black Panther: Wakanda Forever",
              description: "Queen Ramonda, Shuri, M’Baku, Okoye and the Dora Milaje fight to protect their nation from intervening world powers in the wake of King T’Challa’s death.  As the Wakandans strive to embrace their next chapter, the heroes must band together with the help of War Dog Nakia and Everett Ross and forge a new path for the kingdom of Wakanda.",
              moviePoster: URL(string: "https://image.tmdb.org/t/p/w185/sv1xJUazXeYqALzczSZ3O6nkH75.jpg")!,
              voteAverage:7.5,
        voteCount:2879,
              popularity: 7141.639),
        
        
        Movie(movieTitle: "Puss in Boots: ",
              description: "Puss in Boots discovers that his passion for adventure has taken its toll: He has burned through eight of his nine lives, leaving him with only one life left. Puss sets out on an epic journey to find the mythical Last Wish and restore his nine lives.",
              moviePoster: URL(string: "https://image.tmdb.org/t/p/w185/kuf6dutpsT0vSVehic3EZIqkOBt.jpg")!,
              voteAverage:8.5,
        voteCount:3535,
              popularity: 4062.737),
        
        Movie(movieTitle: "Wolf Hound",
              description: "Inspired by the real-life German special operations unit KG 200 that shot down, repaired, and flew Allied aircraft as Trojan horses, \"Wolf Hound\" takes place in 1944 German-occupied France and follows the daring exploits of Jewish-American fighter pilot Captain David Holden. Ambushed behind enemy lines, Holden must rescue a captured B-17 Flying Fortress crew, evade a ruthless enemy stalking him at every turn, and foil a plot that could completely alter the outcome of World War II.",
              moviePoster: URL(string: "https://image.tmdb.org/t/p/w185/gHC0eFvXXNokP3sSNCTG2uks87R.jpg")!,
              voteAverage:7.1,
        voteCount:51,
              popularity: 1177.809),
        


    ]

    // We can now access this array of mock tracks anywhere like this:
    // let Movie = Movie.mockMovies
}
