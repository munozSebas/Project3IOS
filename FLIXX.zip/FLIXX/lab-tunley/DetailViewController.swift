import UIKit
import Nuke

class DetailViewController: UIViewController {

    
    @IBOutlet weak var moviePosterLabel: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var averageLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var popularityLabel: UILabel!
    @IBOutlet weak var overviewLabel: UILabel!
    
    
    // TODO: Pt 1 - Add a track property

    var movie: Movie!

    override func viewDidLoad() {
        super.viewDidLoad()
        overrideUserInterfaceStyle = .dark

        // Load the image located at the `artworkUrl100` URL and set it on the image view.
            Nuke.loadImage(with: movie.moviePoster, into: moviePosterLabel)

            // Set labels with the associated track values.
            movieTitle.text = movie.movieTitle
            overviewLabel.text = movie.description
            averageLabel.text = String(format: "%.2f Vote Average", movie.voteAverage)
            totalLabel.text = String(format:"%d Votes", movie.voteCount)
        popularityLabel.text = String(format: "%.2f Popularity", movie.popularity)

    }



}
